import { storage } from "./storage";
import { sendWhatsAppMessage, sendGeneralNotification } from "./whatsapp-service";
import { format } from 'date-fns';
import { formatInTimeZone } from 'date-fns-tz';

let schedulerInterval: NodeJS.Timeout | null = null;

// Superadmin phone for executive reports
const SUPERADMIN_PHONE = '+917902373354';
const INDIA_TIMEZONE = 'Asia/Kolkata';

/**
 * Get current date/time in IST as formatted string
 */
function getISTDate(date: Date = new Date()): string {
  return formatInTimeZone(date, INDIA_TIMEZONE, 'yyyy-MM-dd');
}

function getISTHour(date: Date = new Date()): number {
  return parseInt(formatInTimeZone(date, INDIA_TIMEZONE, 'H'), 10);
}

function getISTMinute(date: Date = new Date()): number {
  return parseInt(formatInTimeZone(date, INDIA_TIMEZONE, 'm'), 10);
}

/**
 * Check if a report was already sent today (persisted in DB, survives restarts)
 */
async function wasReportSentToday(reportType: 'morning' | 'night'): Promise<boolean> {
  try {
    const type = `daily_${reportType}_report`;
    const logs = await storage.getNotificationLogsByType(type);
    if (logs.length === 0) return false;
    
    // Check if the most recent log is from today (IST)
    const todayIST = getISTDate(new Date());
    const lastLog = logs[0]; // Already sorted by createdAt DESC
    const logDateIST = getISTDate(new Date(lastLog.createdAt || ''));
    
    return logDateIST === todayIST;
  } catch (error) {
    console.error(`[Scheduler] Error checking if ${reportType} report was sent:`, error);
    return false; // If we can't check, err on the side of not sending duplicates
  }
}

/**
 * Log that a report was sent (persists to DB)
 */
async function logReportSent(reportType: 'morning' | 'night'): Promise<void> {
  try {
    await storage.createNotificationLog({
      eventId: null,
      type: `daily_${reportType}_report`,
      recipientPhone: SUPERADMIN_PHONE,
      recipientName: 'Kishor',
      message: `${reportType === 'morning' ? 'Morning' : 'Night'} business report sent`,
      status: 'sent'
    });
  } catch (error) {
    console.error(`[Scheduler] Failed to log ${reportType} report:`, error);
  }
}

const WEDDING_PLANNER_PHONES: Record<string, string> = {
  'fida fathima': '+919895810975',
  'fida': '+919895810975',
  'fida fathima pk': '+919895810975',
  'femina km': '+917306687284',
  'femina': '+917306687284',
};

function getWeddingPlannerPhone(plannerName: string): string | null {
  const normalized = plannerName.toLowerCase().trim();
  for (const [key, phone] of Object.entries(WEDDING_PLANNER_PHONES)) {
    if (normalized.includes(key) || key.includes(normalized)) {
      return phone;
    }
  }
  return null;
}

export async function processReminders(): Promise<void> {
  try {
    const dueReminders = await storage.getDueReminders();
    
    for (const reminder of dueReminders) {
      try {
        const message = `🔔 *Reminder from Oaksy*\n\n${reminder.reminderMessage}\n\n_Set on ${new Date(reminder.createdAt!).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' })}_`;
        
        await sendGeneralNotification(reminder.employeePhone, reminder.employeeName, message);
        await storage.markReminderAsSent(reminder.id);
        
        console.log(`[Reminder Scheduler] Sent reminder to ${reminder.employeeName}: ${reminder.reminderMessage.substring(0, 50)}...`);
      } catch (error) {
        console.error(`[Reminder Scheduler] Failed to send reminder ${reminder.id}:`, error);
      }
    }
    
    if (dueReminders.length > 0) {
      console.log(`[Reminder Scheduler] Processed ${dueReminders.length} reminders`);
    }
  } catch (error) {
    console.error('[Reminder Scheduler] Error processing reminders:', error);
  }
}

export async function process60DayPaymentReminders(): Promise<void> {
  try {
    const eventsDue = await storage.getEventsDueFor60DayReminder();
    
    for (const event of eventsDue) {
      try {
        const plannerPhone = getWeddingPlannerPhone(event.planner);
        
        if (!plannerPhone) {
          console.log(`[60-Day Reminder] No phone found for planner: ${event.planner} - skipping event ${event.id}`);
          continue;
        }
        
        const message = `💰 *Payment Milestone Alert (40%)*\n\n*${event.title}* is scheduled in 2 months.\n\nPlease ensure first payment milestone (40%) is collected and receipt is uploaded.\n\n_Event Date: ${new Date(event.date).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' })}_`;
        
        await sendGeneralNotification(plannerPhone, event.planner || 'Planner', message);
        await storage.markEvent60DayReminderSent(event.id);
        
        await storage.createNotificationLog({
          eventId: event.id,
          type: 'payment_60day',
          recipientPhone: plannerPhone,
          recipientName: event.planner,
          message: message,
          status: 'sent'
        });
        
        console.log(`[60-Day Reminder] Sent payment reminder for event "${event.title}" to ${event.planner} (${plannerPhone})`);
      } catch (error) {
        console.error(`[60-Day Reminder] Failed to send reminder for event ${event.id}:`, error);
        
        try {
          await storage.createNotificationLog({
            eventId: event.id,
            type: 'payment_60day',
            recipientPhone: getWeddingPlannerPhone(event.planner) || 'unknown',
            recipientName: event.planner,
            message: `Failed to send reminder: ${error}`,
            status: 'failed'
          });
        } catch (logError) {
          console.error(`[60-Day Reminder] Failed to log error:`, logError);
        }
      }
    }
    
    if (eventsDue.length > 0) {
      console.log(`[60-Day Reminder] Processed ${eventsDue.length} payment reminders`);
    }
  } catch (error) {
    console.error('[60-Day Reminder] Error processing payment reminders:', error);
  }
}

/**
 * Send daily morning business report to Kishor at 7:00 AM IST
 */
export async function sendMorningBusinessReport(): Promise<void> {
  try {
    const now = new Date();
    const currentHour = getISTHour(now);
    const currentMinute = getISTMinute(now);
    const todayDate = getISTDate(now);
    
    // Only send between 7:00 AM and 7:05 AM IST
    if (currentHour !== 7 || currentMinute > 5) {
      return;
    }
    
    // Check if we've already sent today (persisted in DB, survives restarts)
    if (await wasReportSentToday('morning')) {
      return;
    }
    
    console.log('[Morning Report] Preparing daily business report for Kishor...');
    
    // Get yesterday's date in IST
    const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    const yesterdayDate = getISTDate(yesterday);
    
    // Get this month's date range in IST
    const yearMonth = todayDate.substring(0, 7); // "YYYY-MM"
    const monthStartStr = `${yearMonth}-01`;
    const monthEndStr = todayDate;
    
    // Fetch data for the report
    let yesterdaySales = 0;
    let monthlySales = 0;
    let todaysEvents = 0;
    let todaysMeetings = 0;
    let pendingVendorPayments = 0;
    let pendingClientDues = 0;
    
    try {
      // Get daybook entries for yesterday's sales
      const yesterdayEntries = await storage.getDaybookEntriesByDateRange(yesterdayDate, yesterdayDate);
      yesterdaySales = yesterdayEntries
        .filter((e: any) => e.type === 'income')
        .reduce((sum: number, e: any) => sum + parseFloat(e.amount || '0'), 0);
      
      // Get monthly sales
      const monthlyEntries = await storage.getDaybookEntriesByDateRange(monthStartStr, monthEndStr);
      monthlySales = monthlyEntries
        .filter((e: any) => e.type === 'income')
        .reduce((sum: number, e: any) => sum + parseFloat(e.amount || '0'), 0);
      
      // Get today's events
      const events = await storage.getAllEvents();
      todaysEvents = events.filter((e: any) => e.date === todayDate).length;
      
      // Get today's meetings
      const meetings = await storage.getAllMeetings();
      todaysMeetings = meetings.filter((m: any) => {
        const meetingDate = getISTDate(new Date(m.scheduledAt || m.createdAt || now));
        return meetingDate === todayDate;
      }).length;
      
      // Get pending vendor payments (expenses with pending status)
      const expenses = await storage.getAllExpenseReimbursements();
      pendingVendorPayments = expenses
        .filter((e: any) => e.status === 'pending')
        .reduce((sum: number, e: any) => sum + parseFloat(e.amount || '0'), 0);
      
      // Get pending client dues (events with outstanding balance)
      pendingClientDues = events.reduce((sum: number, e: any) => {
        const salesValue = parseFloat(e.salesValue || '0');
        const paymentReceived = parseFloat(e.paymentReceived || '0');
        return sum + Math.max(0, salesValue - paymentReceived);
      }, 0);
      
    } catch (dataError) {
      console.error('[Morning Report] Error fetching data:', dataError);
    }
    
    const message = `Good morning Kishor ☀️

*Yesterday Sales:* ₹${yesterdaySales.toLocaleString('en-IN')}
*Monthly Total:* ₹${monthlySales.toLocaleString('en-IN')}
*Today's Events:* ${todaysEvents}
*Today's Meetings:* ${todaysMeetings}
*Pending Vendor Payments:* ₹${pendingVendorPayments.toLocaleString('en-IN')}
*Pending Client Dues:* ₹${pendingClientDues.toLocaleString('en-IN')}

_Your Oaksy daily briefing 🌳_`;
    
    const result = await sendGeneralNotification(SUPERADMIN_PHONE, 'Kishor', message);
    if (result.success) {
      await logReportSent('morning');
      console.log('[Morning Report] Sent daily business report to Kishor');
    } else {
      console.error('[Morning Report] Failed to send:', result.error);
    }
  } catch (error) {
    console.error('[Morning Report] Error:', error);
  }
}

/**
 * Send night reminder summary to Kishor after 9:00 PM IST
 */
export async function sendNightReminderSummary(): Promise<void> {
  try {
    const now = new Date();
    const currentHour = getISTHour(now);
    const currentMinute = getISTMinute(now);
    
    // Only send between 9:00 PM and 9:05 PM IST
    if (currentHour !== 21 || currentMinute > 5) {
      return;
    }
    
    // Check if we've already sent today (persisted in DB, survives restarts)
    if (await wasReportSentToday('night')) {
      return;
    }
    
    console.log('[Night Summary] Preparing reminder summary for Kishor...');
    
    // Get tomorrow's date in IST
    const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    const tomorrowDate = getISTDate(tomorrow);
    
    // Get 3 days from now
    const threeDaysLater = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);
    const threeDaysStr = getISTDate(threeDaysLater);
    
    let tomorrowMeetings = 0;
    let tomorrowEvents = 0;
    let tomorrowVendorPayments = 0;
    let upcomingDeadlines = 0;
    
    try {
      // Get tomorrow's meetings
      const meetings = await storage.getAllMeetings();
      tomorrowMeetings = meetings.filter((m: any) => {
        const meetingDate = getISTDate(new Date(m.scheduledAt || m.createdAt || now));
        return meetingDate === tomorrowDate;
      }).length;
      
      // Get tomorrow's events
      const events = await storage.getAllEvents();
      tomorrowEvents = events.filter((e: any) => e.date === tomorrowDate).length;
      
      // Get pending expenses/vendor payments
      const expenses = await storage.getAllExpenseReimbursements();
      tomorrowVendorPayments = expenses.filter((e: any) => e.status === 'pending').length;
      
      // Get upcoming deadlines (events in next 3 days)
      upcomingDeadlines = events.filter((e: any) => {
        if (!e.date) return false;
        return e.date >= tomorrowDate && e.date <= threeDaysStr;
      }).length;
      
    } catch (dataError) {
      console.error('[Night Summary] Error fetching data:', dataError);
    }
    
    const message = `🔔 *Tomorrow Reminder Summary*

*Meetings:* ${tomorrowMeetings}
*Events:* ${tomorrowEvents}
*Vendor Payments Due:* ${tomorrowVendorPayments}
*Deadlines (3 days):* ${upcomingDeadlines}

_Rest well, Kishor! 🌙_`;
    
    const result = await sendGeneralNotification(SUPERADMIN_PHONE, 'Kishor', message);
    if (result.success) {
      await logReportSent('night');
      console.log('[Night Summary] Sent reminder summary to Kishor');
    } else {
      console.error('[Night Summary] Failed to send:', result.error);
    }
  } catch (error) {
    console.error('[Night Summary] Error:', error);
  }
}

/**
 * Process RSVP reminders - send to guests who haven't responded 7 days and 24 hours before event
 */
export async function processRsvpReminders(): Promise<void> {
  try {
    const now = new Date();
    const events = await storage.getAllEvents();
    
    for (const event of events) {
      if (!event.date) continue;
      
      const eventDate = new Date(event.date);
      const hoursUntilEvent = (eventDate.getTime() - now.getTime()) / (1000 * 60 * 60);
      const daysUntilEvent = hoursUntilEvent / 24;
      
      // Skip if event is in the past or more than 8 days away
      if (hoursUntilEvent < 0 || daysUntilEvent > 8) continue;
      
      // Get guests for this event
      const guests = await storage.getEventGuestsByEvent(event.id);
      
      for (const guest of guests) {
        // Check if guest has responded
        const response = await storage.getRsvpResponseByGuest(guest.id);
        if (response && response.attendanceStatus !== 'pending') continue;
        
        // 7 day reminder (between 7 days and 6.5 days - 168 to 156 hours)
        if (hoursUntilEvent <= 168 && hoursUntilEvent > 156 && !(guest as any).reminder7DaySent) {
          try {
            const rsvpLink = guest.rsvpToken ? `${process.env.REPLIT_DEV_DOMAIN || 'https://your-app.replit.app'}/rsvp/${guest.rsvpToken}` : '';
            const eventName = event.customer || event.title;
            const message = `🎉 *RSVP Reminder*\n\nHi ${guest.name}! 👋\n\nFriendly reminder about *${eventName}* on ${format(eventDate, 'MMM d')}!\n\nWe noticed you haven't responded yet. Will you be attending?\n\n${rsvpLink ? `Please confirm here:\n${rsvpLink}` : ''}\n\n_Oakstreet Events_`;
            
            await sendGeneralNotification(guest.phone, guest.name, message);
            await storage.updateEventGuest(guest.id, { reminder7DaySent: true } as any);
            
            console.log(`[RSVP Reminder] Sent 7-day reminder to ${guest.name} for event "${event.title}"`);
          } catch (error) {
            console.error(`[RSVP Reminder] Failed to send 7-day reminder to ${guest.name}:`, error);
          }
        }
        
        // 24h reminder (between 24 and 23 hours) - Final reminder
        if (hoursUntilEvent <= 24 && hoursUntilEvent > 23 && !guest.reminder24hSent) {
          try {
            const rsvpLink = guest.rsvpToken ? `${process.env.REPLIT_DEV_DOMAIN || 'https://your-app.replit.app'}/rsvp/${guest.rsvpToken}` : '';
            const eventName = event.customer || event.title;
            const message = `⏰ *Final RSVP Reminder*\n\nHi ${guest.name}!\n\n*${eventName}* is TOMORROW!\n\nThis is your final reminder to confirm attendance${rsvpLink ? `:\n${rsvpLink}` : ''}\n\n_Oakstreet Events_`;
            
            await sendGeneralNotification(guest.phone, guest.name, message);
            await storage.updateEventGuest(guest.id, { reminder24hSent: true });
            
            console.log(`[RSVP Reminder] Sent 24h reminder to ${guest.name} for event "${event.title}"`);
          } catch (error) {
            console.error(`[RSVP Reminder] Failed to send 24h reminder to ${guest.name}:`, error);
          }
        }
      }
    }
  } catch (error) {
    console.error('[RSVP Reminder] Error processing RSVP reminders:', error);
  }
}

/**
 * Send 24-hour reminders to wedding planners who haven't updated lead stage
 */
async function processPortalLeadReminders(): Promise<void> {
  try {
    // Get all portal leads that are assigned but haven't been updated in 24 hours
    const { db } = await import('./db');
    const { portalLeads, users } = await import('@shared/schema');
    const { eq, and, lt, isNull, isNotNull, or } = await import('drizzle-orm');
    
    const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    
    // Find leads that:
    // 1. Have an assigned planner
    // 2. Phase is still 'assigned' (not progressed)
    // 3. Either phaseUpdatedAt is older than 24 hours OR assignedAt is older than 24 hours (fallback)
    // 4. Reminder hasn't been sent yet
    const staleLeads = await db.select()
      .from(portalLeads)
      .where(
        and(
          isNotNull(portalLeads.assignedPlannerId),
          eq(portalLeads.phase, 'assigned'),
          isNull(portalLeads.reminderSentAt),
          or(
            lt(portalLeads.phaseUpdatedAt, twentyFourHoursAgo),
            and(
              isNull(portalLeads.phaseUpdatedAt),
              lt(portalLeads.assignedAt, twentyFourHoursAgo)
            ),
            and(
              isNull(portalLeads.phaseUpdatedAt),
              isNull(portalLeads.assignedAt),
              lt(portalLeads.updatedAt, twentyFourHoursAgo)
            )
          )
        )
      );
    
    for (const lead of staleLeads) {
      if (!lead.assignedPlannerId) continue;
      
      // Get planner details
      const [planner] = await db.select().from(users).where(eq(users.id, lead.assignedPlannerId));
      if (!planner) continue;
      
      // Get planner's employee record for phone number
      const { employees } = await import('@shared/schema');
      const [employee] = await db.select().from(employees).where(eq(employees.email, planner.email));
      
      if (employee?.phone) {
        const reminderMessage = `⏰ *Reminder: Lead Pending Update*\n\n` +
          `Hi ${planner.name},\n\n` +
          `The lead *${lead.name}* was assigned to you 24 hours ago but the status hasn't been updated.\n\n` +
          `📞 Customer: ${lead.phone}\n` +
          `📧 Email: ${lead.email}\n` +
          `${lead.eventType ? `🎉 Event: ${lead.eventType}` : ''}\n\n` +
          `Please contact the customer and update the lead status in Oak Sales.\n\n` +
          `— Oakstreet Events System`;
        
        try {
          const { sendWhatsAppMessage: sendWA } = await import('./whatsapp-service');
          await sendWA(employee.phone, reminderMessage);
          
          // Mark reminder as sent
          await db.update(portalLeads)
            .set({ reminderSentAt: new Date() })
            .where(eq(portalLeads.id, lead.id));
          
          console.log(`[Portal Lead Reminder] Sent 24h reminder to ${planner.name} for lead ${lead.name}`);
        } catch (error) {
          console.error(`[Portal Lead Reminder] Failed to send reminder for ${lead.name}:`, error);
        }
      }
    }
  } catch (error) {
    console.error('[Portal Lead Reminder] Error processing reminders:', error);
  }
}

async function runAllScheduledTasks(): Promise<void> {
  await processReminders();
  await process60DayPaymentReminders();
  await processRsvpReminders();
  await processPortalLeadReminders();
  await sendMorningBusinessReport();
  await sendNightReminderSummary();
}

export function startReminderScheduler(): void {
  if (schedulerInterval) {
    console.log('[Reminder Scheduler] Scheduler already running');
    return;
  }

  console.log('[Reminder Scheduler] Starting reminder scheduler (checks every 60 seconds)');
  
  runAllScheduledTasks();
  
  schedulerInterval = setInterval(runAllScheduledTasks, 60 * 1000);
}

export function stopReminderScheduler(): void {
  if (schedulerInterval) {
    clearInterval(schedulerInterval);
    schedulerInterval = null;
    console.log('[Reminder Scheduler] Scheduler stopped');
  }
}
