import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "@shared/schema";

const { Pool } = pg;

// Check for DATABASE_URL but don't crash - log error and allow health check to respond
if (!process.env.DATABASE_URL) {
  console.error('[DB] CRITICAL: DATABASE_URL is not set. Database operations will fail.');
  console.error('[DB] Please ensure DATABASE_URL is configured in production secrets.');
}

// Create pool with error handling - use empty string fallback to prevent crash
// The pool will fail on actual queries if URL is invalid, but won't crash on import
export const pool = new Pool({ 
  connectionString: process.env.DATABASE_URL || '',
  // Add connection timeout to prevent hanging
  connectionTimeoutMillis: 10000,
  // Reduce idle timeout in production
  idleTimeoutMillis: 30000,
});

// Handle pool errors gracefully
pool.on('error', (err) => {
  console.error('[DB] Unexpected pool error:', err.message);
});

export const db = drizzle(pool, { schema });
