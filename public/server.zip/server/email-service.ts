import { Resend } from 'resend';

let connectionSettings: any;

async function getCredentials() {
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY 
    ? 'repl ' + process.env.REPL_IDENTITY 
    : process.env.WEB_REPL_RENEWAL 
    ? 'depl ' + process.env.WEB_REPL_RENEWAL 
    : null;

  if (!xReplitToken) {
    throw new Error('X_REPLIT_TOKEN not found for repl/depl');
  }

  connectionSettings = await fetch(
    'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=resend',
    {
      headers: {
        'Accept': 'application/json',
        'X_REPLIT_TOKEN': xReplitToken
      }
    }
  ).then(res => res.json()).then(data => data.items?.[0]);

  if (!connectionSettings || (!connectionSettings.settings.api_key)) {
    throw new Error('Resend not connected');
  }
  return { apiKey: connectionSettings.settings.api_key, fromEmail: connectionSettings.settings.from_email };
}

async function getResendClient() {
  const { apiKey } = await getCredentials();
  return {
    client: new Resend(apiKey),
    fromEmail: connectionSettings.settings.from_email
  };
}

export async function isEmailConfigured(): Promise<boolean> {
  try {
    await getCredentials();
    return true;
  } catch {
    return false;
  }
}

interface SendEmailOptions {
  to: string;
  subject: string;
  html: string;
  attachments?: Array<{
    filename: string;
    content: Buffer;
  }>;
}

export async function sendEmail(options: SendEmailOptions): Promise<{ success: boolean; error?: string; messageId?: string }> {
  try {
    const { client, fromEmail } = await getResendClient();
    
    const result = await client.emails.send({
      from: fromEmail || 'Oakstreet Events <noreply@oakstreetevent.com>',
      to: options.to,
      subject: options.subject,
      html: options.html,
      attachments: options.attachments?.map(att => ({
        filename: att.filename,
        content: att.content
      }))
    });

    if (result.error) {
      return { success: false, error: result.error.message };
    }

    return { success: true, messageId: result.data?.id };
  } catch (error: any) {
    console.error('[Email Service] Send error:', error);
    return { success: false, error: error.message || 'Failed to send email' };
  }
}

export async function sendEstimateEmail(
  to: string,
  customerName: string,
  quoteNumber: string,
  companyName: string,
  pdfBuffer?: Buffer
): Promise<{ success: boolean; error?: string }> {
  const subject = `Estimate ${quoteNumber} from ${companyName}`;
  
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #2d5a3d;">Estimate from ${companyName}</h2>
      <p>Dear ${customerName},</p>
      <p>Thank you for considering ${companyName} for your event. Please find attached the estimate <strong>${quoteNumber}</strong> for your review.</p>
      <p>If you have any questions or would like to discuss the details, please don't hesitate to reach out.</p>
      <br/>
      <p>Best regards,</p>
      <p><strong>${companyName}</strong></p>
      <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;"/>
      <p style="color: #666; font-size: 12px;">This is an automated message from ${companyName}.</p>
    </div>
  `;

  const attachments = pdfBuffer ? [{
    filename: `${quoteNumber}.pdf`,
    content: pdfBuffer
  }] : undefined;

  return sendEmail({ to, subject, html, attachments });
}

export async function sendInvoiceEmail(
  to: string,
  customerName: string,
  invoiceNumber: string,
  companyName: string,
  pdfBuffer?: Buffer
): Promise<{ success: boolean; error?: string }> {
  const subject = `Invoice ${invoiceNumber} from ${companyName}`;
  
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #2d5a3d;">Invoice from ${companyName}</h2>
      <p>Dear ${customerName},</p>
      <p>Please find attached the invoice <strong>${invoiceNumber}</strong> for your reference.</p>
      <p>If you have any questions regarding this invoice, please feel free to contact us.</p>
      <br/>
      <p>Best regards,</p>
      <p><strong>${companyName}</strong></p>
      <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;"/>
      <p style="color: #666; font-size: 12px;">This is an automated message from ${companyName}.</p>
    </div>
  `;

  const attachments = pdfBuffer ? [{
    filename: `${invoiceNumber}.pdf`,
    content: pdfBuffer
  }] : undefined;

  return sendEmail({ to, subject, html, attachments });
}
