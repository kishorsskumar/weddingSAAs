import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/context/auth-context";
import Layout from "@/components/layout";
import { motion, AnimatePresence } from "framer-motion";
import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import EventCalendar from "@/pages/event-calendar";
import TeamCalendar from "@/pages/team-calendar";
import EventDatabase from "@/pages/event-database";
import EventMilestones from "@/pages/event-milestones";
import Daybook from "@/pages/daybook";
import OakBook from "@/pages/oak-book";
import HR from "@/pages/hr";
import Admin from "@/pages/admin";
import OakSales from "@/pages/oak-sales";
import OakInventory from "@/pages/oak-inventory";
import ExecutionPlan from "@/pages/execution-plan";
import CustomerPortal from "@/pages/customer-portal";
import PrintDocument from "@/pages/print-document";
import EmployeePortal from "@/pages/employee-portal";
import Oaksy from "@/pages/oaksy";
import OakCreative from "@/pages/oak-creative";
import OakRSVP from "@/pages/oak-rsvp";
import RsvpResponse from "@/pages/rsvp-response";
import RsvpLanding from "@/pages/rsvp-landing";
import RsvpFlowPdf from "@/pages/rsvp-flow-pdf";
import ClientPortalGuidePdf from "@/pages/client-portal-guide-pdf";
import DownloadFiles from "@/pages/download-files";
import PrintMilestones from "@/pages/print-milestones";
import MonthlyPlan from "@/pages/monthly-plan";
import WhatsappInbox from "@/pages/whatsapp-inbox";
import ManagementMIS from "@/pages/management-mis";
import DownloadPage from "@/pages/download";
import PortalLanding from "@/pages/portal-landing";
import ClientPortal from "@/pages/client-portal";
import MyPortal from "@/pages/my-portal";
import PortfolioPage from "@/pages/portfolio-page";
import PortfolioAdmin from "@/pages/portfolio-admin";
import NotFound from "@/pages/not-found";
import { useEffect, Component, type ReactNode, type ErrorInfo } from "react";

class GlobalErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean; error: Error | null }> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Global React Error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: '20px', textAlign: 'center', fontFamily: 'Inter, sans-serif' }}>
          <h1 style={{ color: '#4b7c29' }}>Something went wrong</h1>
          <p style={{ color: '#666' }}>Please refresh the page or contact support.</p>
          <button 
            onClick={() => window.location.reload()} 
            style={{ 
              padding: '10px 20px', 
              backgroundColor: '#4b7c29', 
              color: 'white', 
              border: 'none', 
              borderRadius: '5px',
              cursor: 'pointer',
              marginTop: '10px'
            }}
          >
            Refresh Page
          </button>
          {this.state.error && (
            <pre style={{ textAlign: 'left', marginTop: '20px', padding: '10px', background: '#f5f5f5', borderRadius: '5px', fontSize: '12px', overflow: 'auto' }}>
              {this.state.error.message}
            </pre>
          )}
        </div>
      );
    }
    return this.props.children;
  }
}

function PrivateRoute({ component: Component, path }: { component: any; path: string }) {
  const { user, isLoading } = useAuth();
  const [location, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && !user) {
      setLocation("/login");
    }
  }, [user, isLoading, setLocation]);

  if (isLoading || !user) return null; 

  return <Component />;
}

function AppRoutes() {
  return (
    <Layout>
      <Switch>
        <Route path="/login" component={Login} />
        <Route path="/">
          <PrivateRoute component={Dashboard} path="/" />
        </Route>
        <Route path="/events">
          <PrivateRoute component={EventCalendar} path="/events" />
        </Route>
        <Route path="/monthly-plan">
          <PrivateRoute component={MonthlyPlan} path="/monthly-plan" />
        </Route>
        <Route path="/team">
           <PrivateRoute component={TeamCalendar} path="/team" />
        </Route>
        <Route path="/database">
           <PrivateRoute component={EventDatabase} path="/database" />
        </Route>
        <Route path="/milestones">
           <PrivateRoute component={EventMilestones} path="/milestones" />
        </Route>
        <Route path="/daybook">
           <PrivateRoute component={Daybook} path="/daybook" />
        </Route>
        <Route path="/oak-book">
           <PrivateRoute component={OakBook} path="/oak-book" />
        </Route>
        <Route path="/hr">
           <PrivateRoute component={HR} path="/hr" />
        </Route>
        <Route path="/admin">
           <PrivateRoute component={Admin} path="/admin" />
        </Route>
        <Route path="/oak-sales">
           <PrivateRoute component={OakSales} path="/oak-sales" />
        </Route>
        <Route path="/oak-inventory">
           <PrivateRoute component={OakInventory} path="/oak-inventory" />
        </Route>
        <Route path="/execution-plan">
           <PrivateRoute component={ExecutionPlan} path="/execution-plan" />
        </Route>
        <Route path="/employee-portal">
           <PrivateRoute component={EmployeePortal} path="/employee-portal" />
        </Route>
        <Route path="/oaksy">
           <PrivateRoute component={Oaksy} path="/oaksy" />
        </Route>
        <Route path="/oak-creative">
           <PrivateRoute component={OakCreative} path="/oak-creative" />
        </Route>
        <Route path="/portfolio-admin">
           <PrivateRoute component={PortfolioAdmin} path="/portfolio-admin" />
        </Route>
        <Route path="/whatsapp-inbox">
           <PrivateRoute component={WhatsappInbox} path="/whatsapp-inbox" />
        </Route>
        <Route path="/oak-rsvp">
           <PrivateRoute component={OakRSVP} path="/oak-rsvp" />
        </Route>
        <Route path="/management-mis">
           <PrivateRoute component={ManagementMIS} path="/management-mis" />
        </Route>
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <GlobalErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <AuthProvider>
            <Switch>
            <Route path="/portal/:token">
              <CustomerPortal />
            </Route>
            <Route path="/print/milestones/:eventId">
              <PrintMilestones />
            </Route>
            <Route path="/print/:type/:id">
              <PrintDocument />
            </Route>
            <Route path="/download">
              <DownloadPage />
            </Route>
            <Route path="/rsvp/:token">
              <RsvpResponse />
            </Route>
            <Route path="/rsvp-service">
              <RsvpLanding />
            </Route>
            <Route path="/rsvp-flow-pdf">
              <RsvpFlowPdf />
            </Route>
            <Route path="/client-portal-guide-pdf">
              <ClientPortalGuidePdf />
            </Route>
            <Route path="/download-files">
              <DownloadFiles />
            </Route>
            <Route path="/my-portal">
              <MyPortal />
            </Route>
            <Route path="/client-portal">
              <PortalLanding />
            </Route>
            <Route path="/client-portal/:token">
              <ClientPortal />
            </Route>
            <Route path="/portfolio">
              <PortfolioPage />
            </Route>
            <Route path="/portfolio/:id">
              <PortfolioPage />
            </Route>
            <Route>
              <AppRoutes />
            </Route>
            </Switch>
            <Toaster />
          </AuthProvider>
        </TooltipProvider>
      </QueryClientProvider>
    </GlobalErrorBoundary>
  );
}

export default App;
