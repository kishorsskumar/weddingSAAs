import { createContext, useContext, useState, ReactNode, useEffect } from "react";
import { useLocation } from "wouter";
import { queryClient } from "@/lib/queryClient";
import { registerPushSubscription } from "@/lib/push-notifications";

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  avatar: string | null;
  createdVia: string | null;
}

interface AuthContextType {
  user: User | null;
  allowedPages: string[];
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [allowedPages, setAllowedPages] = useState<string[]>([]);
  const [_, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(true);

  // Clear all caches helper
  const clearAllCaches = async () => {
    try {
      queryClient.clear();
      queryClient.removeQueries();
      localStorage.clear();
      sessionStorage.clear();
      if ('caches' in window) {
        const cacheNames = await caches.keys();
        await Promise.all(cacheNames.map(name => caches.delete(name)));
      }
    } catch (e) {
      console.error('Error clearing caches:', e);
    }
  };

  // Check if user is already logged in
  useEffect(() => {
    fetch('/api/auth/me', { credentials: 'include' })
      .then(res => {
        if (res.ok) return res.json();
        throw new Error('Not authenticated');
      })
      .then(data => {
        setUser(data.user);
        setAllowedPages(data.permissions);
        registerPushSubscription();
      })
      .catch(async () => {
        // Not logged in - clear any stale cached data
        await clearAllCaches();
        setUser(null);
        setAllowedPages([]);
      })
      .finally(() => setIsLoading(false));
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    // Clear any cached data from previous user before login
    queryClient.clear();
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      if (!response.ok) {
        throw new Error('Invalid credentials');
      }

      const data = await response.json();
      setUser(data.user);
      setAllowedPages(data.permissions);
      registerPushSubscription();
      
      // Route based on how user was created
      if (data.user.createdVia === 'employee_onboarding') {
        setLocation("/employee-portal");
      } else {
        setLocation("/");
      }
    } catch (error) {
      alert('Login failed. Please check your credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
    await clearAllCaches();
    setUser(null);
    setAllowedPages([]);
    setLocation("/login");
  };

  return (
    <AuthContext.Provider value={{ user, allowedPages, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
