import { useState, useEffect } from "react";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { format, parseISO } from "date-fns";
import { Calendar, MapPin, Users, UtensilsCrossed, Check, X, HelpCircle, Loader2, Download } from "lucide-react";

interface GuestData {
  id: string;
  name: string;
  eventId: string;
  maxAttendees: number;
  event: {
    id: string;
    title: string;
    date: string;
    venue?: string;
    customer?: string;
  };
  existingResponse?: {
    attendanceStatus: string;
    numberOfAttendees: number;
    mealPreference?: string;
    specialNotes?: string;
  };
}

export default function RsvpResponse() {
  const [, params] = useRoute("/rsvp/:token");
  const token = params?.token;
  
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [guestData, setGuestData] = useState<GuestData | null>(null);
  
  const [attendance, setAttendance] = useState<string>("");
  const [guestCount, setGuestCount] = useState(1);
  const [mealPreference, setMealPreference] = useState<string>("");
  const [specialNotes, setSpecialNotes] = useState("");
  
  const { toast } = useToast();

  useEffect(() => {
    if (!token) return;
    
    const fetchGuestData = async () => {
      try {
        const res = await fetch(`/api/rsvp/public/${token}`);
        if (!res.ok) {
          if (res.status === 404) {
            setError("This RSVP link is invalid or has expired.");
          } else {
            setError("Unable to load RSVP information. Please try again.");
          }
          setLoading(false);
          return;
        }
        
        const data = await res.json();
        setGuestData(data);
        
        if (data.existingResponse) {
          setAttendance(data.existingResponse.attendanceStatus);
          setGuestCount(data.existingResponse.numberOfAttendees || 1);
          setMealPreference(data.existingResponse.mealPreference || "");
          setSpecialNotes(data.existingResponse.specialNotes || "");
        }
        
        setLoading(false);
      } catch (err) {
        setError("Unable to load RSVP information. Please try again.");
        setLoading(false);
      }
    };
    
    fetchGuestData();
  }, [token]);

  const handleSubmit = async () => {
    if (!attendance) {
      toast({
        title: "Please select your attendance",
        variant: "destructive",
      });
      return;
    }
    
    setSubmitting(true);
    
    try {
      const res = await fetch(`/api/rsvp/public/${token}/respond`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          attendanceStatus: attendance,
          numberOfAttendees: attendance === "yes" ? guestCount : 0,
          mealPreference: attendance === "yes" ? mealPreference : null,
          specialNotes,
        }),
      });
      
      if (!res.ok) {
        throw new Error("Failed to submit response");
      }
      
      setSubmitted(true);
      toast({
        title: "Thank you!",
        description: "Your RSVP has been recorded.",
      });
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to submit your response. Please try again.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-green-50 to-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-green-600" />
            <span className="ml-3 text-gray-600">Loading your invitation...</span>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-red-50 to-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <X className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <CardTitle className="text-red-600">Invalid Link</CardTitle>
            <CardDescription>{error}</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  const handleDownloadConfirmation = () => {
    if (!guestData) return;
    
    const eventDate = guestData.event.date ? parseISO(guestData.event.date) : null;
    const eventDateStr = eventDate ? format(eventDate, "EEEE, MMMM d, yyyy") : 'Date TBD';
    const eventName = guestData.event.customer || guestData.event.title;
    
    // Create downloadable confirmation content
    const confirmationContent = `
═══════════════════════════════════════════════════
                 RSVP CONFIRMATION
═══════════════════════════════════════════════════

Event: ${eventName}
Date: ${eventDateStr}
${guestData.event.venue ? `Venue: ${guestData.event.venue}` : ''}

───────────────────────────────────────────────────

Guest Name: ${guestData.name}
Status: ${attendance === 'yes' ? '✓ ATTENDING' : attendance === 'no' ? '✗ NOT ATTENDING' : '? MAYBE'}
${attendance === 'yes' ? `Number of Guests: ${guestCount}` : ''}
${attendance === 'yes' && mealPreference ? `Meal Preference: ${mealPreference === 'veg' ? 'Vegetarian' : 'Non-Vegetarian'}` : ''}
${specialNotes ? `Notes: ${specialNotes}` : ''}

───────────────────────────────────────────────────

Confirmed on: ${format(new Date(), "MMMM d, yyyy 'at' h:mm a")}

═══════════════════════════════════════════════════
           Managed by Oakstreet Events
             www.oakstreetevents.com
═══════════════════════════════════════════════════
    `.trim();
    
    // Create and download file
    const blob = new Blob([confirmationContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `RSVP-Confirmation-${guestData.name.replace(/\s+/g, '-')}.txt`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-green-50 to-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <Check className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <CardTitle className="text-green-600 text-2xl">Thank You!</CardTitle>
            <CardDescription className="text-lg">
              Your RSVP for {guestData?.event.title} has been recorded.
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <div className="text-gray-600">
              {attendance === "yes" ? (
                <p>We look forward to seeing you there!</p>
              ) : attendance === "no" ? (
                <p>We're sorry you won't be able to make it. We'll miss you!</p>
              ) : (
                <p>We hope you can join us. Feel free to update your response anytime.</p>
              )}
            </div>
            
            {attendance === "yes" && (
              <div className="pt-4 border-t">
                <Button 
                  onClick={handleDownloadConfirmation}
                  className="bg-green-600 hover:bg-green-700"
                  data-testid="button-download-confirmation"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download Confirmation
                </Button>
                <p className="text-xs text-gray-500 mt-2">
                  Save this as proof of your RSVP
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!guestData) return null;

  const eventDate = guestData.event.date ? parseISO(guestData.event.date) : null;

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white py-8 px-4">
      <div className="max-w-lg mx-auto space-y-6">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-serif text-gray-800 mb-2">You're Invited!</h1>
          <p className="text-gray-600">Please respond to this invitation</p>
        </div>

        <Card className="border-green-200 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-green-600 to-green-700 text-white rounded-t-lg">
            <CardTitle className="text-2xl text-center">{guestData.event.title}</CardTitle>
            {guestData.event.customer && (
              <CardDescription className="text-green-100 text-center">
                Hosted by {guestData.event.customer}
              </CardDescription>
            )}
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4 mb-6">
              {eventDate && (
                <div className="flex items-center gap-3 text-gray-700">
                  <Calendar className="h-5 w-5 text-green-600" />
                  <span>{format(eventDate, "EEEE, MMMM d, yyyy")}</span>
                </div>
              )}
              {guestData.event.venue && (
                <div className="flex items-center gap-3 text-gray-700">
                  <MapPin className="h-5 w-5 text-green-600" />
                  <span>{guestData.event.venue}</span>
                </div>
              )}
            </div>

            <div className="border-t pt-6 space-y-6">
              <div className="text-center">
                <p className="text-lg text-gray-700 mb-1">Dear <span className="font-semibold">{guestData.name}</span>,</p>
                <p className="text-gray-600">Will you be attending?</p>
              </div>

              <RadioGroup
                value={attendance}
                onValueChange={setAttendance}
                className="grid grid-cols-3 gap-3"
                data-testid="radio-attendance"
              >
                <div>
                  <RadioGroupItem value="yes" id="yes" className="peer sr-only" data-testid="radio-attendance-yes" />
                  <Label
                    htmlFor="yes"
                    className="flex flex-col items-center justify-center rounded-lg border-2 border-gray-200 p-4 cursor-pointer hover:bg-green-50 peer-data-[state=checked]:border-green-600 peer-data-[state=checked]:bg-green-50 transition-all"
                  >
                    <Check className="h-8 w-8 mb-2 text-green-600" />
                    <span className="font-medium">Attending</span>
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="no" id="no" className="peer sr-only" data-testid="radio-attendance-no" />
                  <Label
                    htmlFor="no"
                    className="flex flex-col items-center justify-center rounded-lg border-2 border-gray-200 p-4 cursor-pointer hover:bg-red-50 peer-data-[state=checked]:border-red-600 peer-data-[state=checked]:bg-red-50 transition-all"
                  >
                    <X className="h-8 w-8 mb-2 text-red-600" />
                    <span className="font-medium">Not Attending</span>
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="maybe" id="maybe" className="peer sr-only" data-testid="radio-attendance-maybe" />
                  <Label
                    htmlFor="maybe"
                    className="flex flex-col items-center justify-center rounded-lg border-2 border-gray-200 p-4 cursor-pointer hover:bg-yellow-50 peer-data-[state=checked]:border-yellow-600 peer-data-[state=checked]:bg-yellow-50 transition-all"
                  >
                    <HelpCircle className="h-8 w-8 mb-2 text-yellow-600" />
                    <span className="font-medium">Maybe</span>
                  </Label>
                </div>
              </RadioGroup>

              {attendance === "yes" && (
                <div className="space-y-6 animate-in fade-in slide-in-from-top-2">
                  <div>
                    <Label className="flex items-center gap-2 mb-3">
                      <Users className="h-4 w-4" />
                      Number of Guests (including yourself)
                    </Label>
                    <div className="flex items-center gap-4">
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => setGuestCount(Math.max(1, guestCount - 1))}
                        disabled={guestCount <= 1}
                        data-testid="button-decrease-guests"
                      >
                        -
                      </Button>
                      <span className="text-2xl font-semibold w-12 text-center" data-testid="text-guest-count">{guestCount}</span>
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => setGuestCount(Math.min(guestData.maxAttendees, guestCount + 1))}
                        disabled={guestCount >= guestData.maxAttendees}
                        data-testid="button-increase-guests"
                      >
                        +
                      </Button>
                      <span className="text-sm text-gray-500">Max: {guestData.maxAttendees}</span>
                    </div>
                  </div>

                  <div>
                    <Label className="flex items-center gap-2 mb-3">
                      <UtensilsCrossed className="h-4 w-4" />
                      Meal Preference
                    </Label>
                    <RadioGroup
                      value={mealPreference}
                      onValueChange={setMealPreference}
                      className="grid grid-cols-2 gap-3"
                      data-testid="radio-meal"
                    >
                      <div>
                        <RadioGroupItem value="vegetarian" id="veg" className="peer sr-only" data-testid="radio-meal-veg" />
                        <Label
                          htmlFor="veg"
                          className="flex items-center justify-center rounded-lg border-2 border-gray-200 p-3 cursor-pointer hover:bg-green-50 peer-data-[state=checked]:border-green-600 peer-data-[state=checked]:bg-green-50 transition-all"
                        >
                          <span className="h-3 w-3 rounded-full bg-green-500 mr-2"></span>
                          Vegetarian
                        </Label>
                      </div>
                      <div>
                        <RadioGroupItem value="non_vegetarian" id="nonveg" className="peer sr-only" data-testid="radio-meal-nonveg" />
                        <Label
                          htmlFor="nonveg"
                          className="flex items-center justify-center rounded-lg border-2 border-gray-200 p-3 cursor-pointer hover:bg-red-50 peer-data-[state=checked]:border-red-600 peer-data-[state=checked]:bg-red-50 transition-all"
                        >
                          <span className="h-3 w-3 rounded-full bg-red-500 mr-2"></span>
                          Non-Vegetarian
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>
                </div>
              )}

              <div>
                <Label htmlFor="notes" className="mb-2 block">Any special notes or dietary requirements?</Label>
                <Textarea
                  id="notes"
                  value={specialNotes}
                  onChange={(e) => setSpecialNotes(e.target.value)}
                  placeholder="Let us know if you have any special requests..."
                  className="resize-none"
                  rows={3}
                  data-testid="input-special-notes"
                />
              </div>

              <Button
                onClick={handleSubmit}
                disabled={submitting || !attendance}
                className="w-full bg-green-600 hover:bg-green-700 text-lg py-6"
                data-testid="button-submit-rsvp"
              >
                {submitting ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin mr-2" />
                    Submitting...
                  </>
                ) : (
                  "Submit RSVP"
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        <p className="text-center text-sm text-gray-500">
          Powered by Oakstreet Events
        </p>
      </div>
    </div>
  );
}
